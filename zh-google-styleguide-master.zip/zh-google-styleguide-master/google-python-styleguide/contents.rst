.. 请确保至少包含基本的 `toctree` 指令.

.. _python_contents:

Python 风格指南 - 内容目录
==========================

.. toctree::

   index
